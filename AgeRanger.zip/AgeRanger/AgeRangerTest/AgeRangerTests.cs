﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AgeRanger.Models;
using System.Web.Http;

namespace AgeRangerTest
{
    [TestClass]
    public class AgeRangerTests
    {
        AgeRanger.Models.AgeRangerEntities db = new AgeRanger.Models.AgeRangerEntities();
        private AgeRanger.Controllers.PeopleController obj = new AgeRanger.Controllers.PeopleController();
        private Person oTestPerson = new Person();

        public AgeRangerTests()
        {
            oTestPerson.Id = 0;
            oTestPerson.FirstName = "Test Case";
            oTestPerson.LastName = "User";
            oTestPerson.Age = 10;
        }

        [TestMethod]
        public void Test_AddandFindPerson()
        {
            

            db.Person.Add(oTestPerson);
            db.SaveChanges();

            Person ReturnPerson = db.Person.Find(oTestPerson.Id);
            oTestPerson.Id = ReturnPerson.Id;
            Assert.AreEqual(ReturnPerson, oTestPerson);

            
            db.Dispose();

        }

        [TestMethod]
        public void Test_PutPerson()
        {

            int iPersonId = 10; //update this to valid id
            oTestPerson = db.Person.Find(iPersonId);
        
            Person oEditPerson = db.Person.Find(iPersonId);

            oEditPerson.FirstName = oTestPerson.FirstName + "-EDIT";
            oEditPerson.LastName = oTestPerson.LastName + "-EDIT";
            oEditPerson.Age = oTestPerson.Age + 100;

            db.SaveChanges();

            oEditPerson = db.Person.Find(oTestPerson.Id);
            Assert.AreEqual(oTestPerson, oEditPerson);
            db.Dispose();

        }

        [TestMethod]
        public void Test_DeletePerson()
        {
            int iPersonId = 10; //update this to valid id
            Person oDeletePerson = db.Person.Find(iPersonId);
            db.Person.Remove(oDeletePerson);
            db.SaveChanges();

            Person oDeletedPerson = db.Person.Find(iPersonId);

            Assert.AreEqual(null, oDeletedPerson);

        }

    }
}
