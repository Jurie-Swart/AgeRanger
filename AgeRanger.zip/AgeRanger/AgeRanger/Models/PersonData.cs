﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace AgeRanger.Models
{
    public class PersonData { 

        private Models.AgeRangerEntities db = new Models.AgeRangerEntities();

        public DataTable GetPeople()
        {
            DataTable dtbPeople = new DataTable();
            dtbPeople.Columns.Add("Id", typeof(int));
            dtbPeople.Columns.Add("FirstName", typeof(string));
            dtbPeople.Columns.Add("LastName", typeof(string));
            dtbPeople.Columns.Add("Age", typeof(int));

            IQueryable<Person> oPeople = db.Person;
            
            foreach (Person oPerson in oPeople)
            {
                DataRow dtrPerson;
                dtrPerson = dtbPeople.NewRow();
                dtrPerson["Id"] = oPerson.Id;
                dtrPerson["FirstName"] = oPerson.FirstName;
                dtrPerson["LastName"] = oPerson.LastName;
                dtrPerson["Age"] = oPerson.Age;
                dtbPeople.Rows.Add(dtrPerson);
                dtrPerson = null;
            }

            return dtbPeople;
        }

        public DataTable GetPeopleWithAgeGroup()
        {
            DataTable dtbPeople = new DataTable();
            dtbPeople.Columns.Add("Id", typeof(int));
            dtbPeople.Columns.Add("FirstName", typeof(string));
            dtbPeople.Columns.Add("LastName", typeof(string));
            dtbPeople.Columns.Add("Age", typeof(int));
            dtbPeople.Columns.Add("AgeGroup", typeof(string));

            IQueryable<Person> oPeople = db.Person;

            AgeGroupData oAgeGroupData = new AgeGroupData();

            foreach (Person oPerson in oPeople)
            {
                DataRow dtrPerson;
                dtrPerson = dtbPeople.NewRow();
                dtrPerson["Id"] = oPerson.Id;
                dtrPerson["FirstName"] = oPerson.FirstName;
                dtrPerson["LastName"] = oPerson.LastName;
                dtrPerson["Age"] = oPerson.Age;
                dtrPerson["AgeGroup"] = oAgeGroupData.GetAgeGroupForAge(oPerson.Age);
                dtbPeople.Rows.Add(dtrPerson);
                dtrPerson = null;
            }

            return dtbPeople;
        }
    }


}