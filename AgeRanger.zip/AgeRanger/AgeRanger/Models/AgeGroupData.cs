﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace AgeRanger.Models
{
    public class AgeGroupData
    {
        private DataTable _AgeGroups = new DataTable();

       public DataTable AgeGroups {
            get
            {
                return _AgeGroups;
            }
        }

        private Models.AgeRangerEntities db = new Models.AgeRangerEntities();

        public AgeGroupData()
        {
            _AgeGroups = GetAgeGroup();
        }


        private DataTable GetAgeGroup()
        {
            DataTable dtbAgeGroup = new DataTable();
            dtbAgeGroup.Columns.Add("Id", typeof(int));
            dtbAgeGroup.Columns.Add("MinAge", typeof(int));
            dtbAgeGroup.Columns.Add("MaxAge", typeof(int));
            dtbAgeGroup.Columns.Add("Description", typeof(string));

            System.Data.SQLite.SQLiteConnection dbConn = new System.Data.SQLite.SQLiteConnection();
            try
            {
               
                dbConn = new System.Data.SQLite.SQLiteConnection(System.Configuration.ConfigurationManager.ConnectionStrings["AgeRangerContext"].ToString());
                dbConn.Open();
                System.Data.SQLite.SQLiteCommand dbComm = new System.Data.SQLite.SQLiteCommand();
                dbComm.Connection = dbConn;
                dbComm.CommandText = "SELECT [Extent1].[Id] AS [Id], [Extent1].[MinAge] AS [MinAge], [Extent1].[MaxAge] AS [MaxAge], [Extent1].[Description] AS [Description] FROM [AgeGroup] AS [Extent1]";

                System.Data.SQLite.SQLiteDataReader dbReader = dbComm.ExecuteReader();

                if (dbReader.HasRows)
                {
                    while (dbReader.Read())
                    {
                        Models.AgeGroup oAgeGroup = new AgeGroup();
                        oAgeGroup.Id = (long) dbReader["Id"];


                        if (dbReader["MinAge"] != System.DBNull.Value)
                        {
                            oAgeGroup.MinAge = (long?)dbReader["MinAge"];
                        }
                        else
                        {
                            oAgeGroup.MinAge = -1;
                        }

                        if (dbReader["MaxAge"] != System.DBNull.Value)
                        {
                            oAgeGroup.MaxAge = (long?) dbReader["MaxAge"];
                        }
                        else
                        {
                            oAgeGroup.MaxAge = -1;
                        }
                       
                                               
                        oAgeGroup.Description = (string) dbReader["Description"];
                        
                        DataRow drpAgeGroup;
                        drpAgeGroup = dtbAgeGroup.NewRow();
                        drpAgeGroup["Id"] = oAgeGroup.Id;
                        drpAgeGroup["MinAge"] = oAgeGroup.MinAge;
                
                        drpAgeGroup["MaxAge"] = oAgeGroup.MaxAge;
                        drpAgeGroup["Description"] = oAgeGroup.Description;
                        dtbAgeGroup.Rows.Add(drpAgeGroup);
                        drpAgeGroup = null;
                    }
                }
                dbReader.Close();
                dbReader = null;
              

            }
            catch (Exception ex) {
                string strError = ex.Message;
            }
            finally
            {
                if (dbConn.State != ConnectionState.Closed)
                {
                    dbConn.Close();
                    dbConn.Dispose();
                    dbConn = null;
                }

            }

            return dtbAgeGroup;
        }

        public string GetAgeGroupForAge(long? Age)
        {
            string strReturn = "";
            try
            {
                if (Age != null)
                {
                    DataTable dtbAgeGroup = _AgeGroups;
                    if (dtbAgeGroup.Select("(MinAge<=" + Age + " or MinAge=-1) and (MaxAge>" + Age + " or MaxAge=-1)").Length > 0)
                    {
                        strReturn = (string)dtbAgeGroup.Select("(MinAge<=" + Age + " or MinAge=-1) and (MaxAge>" + Age + " or MaxAge=-1)")[0]["Description"];
                    }
                }
            } catch { }

            return strReturn;
       }
    }
}