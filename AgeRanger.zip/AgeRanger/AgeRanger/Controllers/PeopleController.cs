﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace AgeRanger.Controllers
{
    public class PeopleController : ApiController
    {
        private Models.AgeRangerEntities db = new Models.AgeRangerEntities();

        // GET: api/People
        public DataTable GetPerson()
        {
            Models.PersonData oPersonData = new Models.PersonData();
            DataTable dtbPeople = oPersonData.GetPeopleWithAgeGroup();
            return dtbPeople;
        }

        public DataTable GetPeopleOnFirstName(string FirstName)
        {
            Models.PersonData oPersonData = new Models.PersonData();
            DataTable dtbPeople = oPersonData.GetPeopleWithAgeGroup();
            DataTable dtbPeopleFiltered = dtbPeople.Copy();
            dtbPeople.Rows.Clear();
            dtbPeopleFiltered.Select("FirstName like '%" + FirstName + "%'").CopyToDataTable<DataRow>(dtbPeople, LoadOption.OverwriteChanges);
            return dtbPeople;
        }

        public DataTable GetPeopleOnLastName(string LastName)
        {

            Models.PersonData oPersonData = new Models.PersonData();
            DataTable dtbPeople = oPersonData.GetPeopleWithAgeGroup();
            DataTable dtbPeopleFiltered = dtbPeople.Copy();
            dtbPeople.Rows.Clear();
            dtbPeopleFiltered.Select("LastName like '%" + LastName + "%'").CopyToDataTable<DataRow>(dtbPeople, LoadOption.OverwriteChanges);
            return dtbPeople;
            
        }

        // GET: api/People/5
        [ResponseType(typeof(Models.Person))]
        public IHttpActionResult GetPerson(long id)
        {
            try
            {
            Models.Person person = db.Person.Find(id);
            if (person == null)
            {
                return NotFound();
            }

            return Ok(person);
            }
            catch (Exception Ex)
            {
                return BadRequest(Ex.Message);
            }
        }

        // PUT: api/People/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutPerson(long id, Models.Person person)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (id != person.Id)
                {
                    return BadRequest();
                }

                if (person.Age == null)
                {
                    return BadRequest("Not a valid age entered");
                }

                if (person.Age < 0)
                {
                    return BadRequest("Age can not be less than 0");
                }

                //2147483647
                if (person.Age > 2147483647)
                {
                    return BadRequest("Age can not be more than 2147483647");
                }

                db.Entry(person).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PersonExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return StatusCode(HttpStatusCode.NoContent);
            }
            catch (Exception Ex)
            {
                return BadRequest(Ex.Message);
            }
        }

        // POST: api/People
        [ResponseType(typeof(Models.Person))]
        public IHttpActionResult PostPerson(Models.Person person)
        {
            try
            {
                if (person.Age == null)
            {
                return BadRequest("Not a valid age entered");
            }

            if (person.Age < 0)
            {
                return BadRequest("Age can not be less than 0");
            }

            //2147483647
            if (person.Age > 2147483647)
            {
                return BadRequest("Age can not be more than 2147483647");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Person.Add(person);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = person.Id }, person);
            }
            catch (Exception Ex)
            {
                return BadRequest(Ex.Message);
            }
                       
        }

        // DELETE: api/People/5
        [ResponseType(typeof(Models.Person))]
        public IHttpActionResult DeletePerson(long id)
        {
            try
            {
                Models.Person person = db.Person.Find(id);
                if (person == null)
                {
                    return NotFound();
                }

                db.Person.Remove(person);
                db.SaveChanges();

                return Ok(person);
            }
            catch (Exception Ex)
            {
                return BadRequest(Ex.Message);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PersonExists(long id)
        {
            return db.Person.Count(e => e.Id == id) > 0;
        }
    }
}