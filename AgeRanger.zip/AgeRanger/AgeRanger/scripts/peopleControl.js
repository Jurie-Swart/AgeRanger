﻿
app.controller('PeopleCtrl', function ($scope, $http) {
    $scope.Peoplefound = false;
    $scope.ErrorMessage = "";
    $scope.ShowErrorMessage = false;
    $scope.SetErrorMessage = function (Message) {
        $scope.ErrorMessage = Message + "";
        $scope.ShowErrorMessage = false;
        if ($scope.ErrorMessage != "") {
            $scope.ShowErrorMessage = true;
        }
    }
    $scope.EditTitle = "Add new person";
    $scope.ShowEditForm = false;
    $scope.FirstNameSearch = "";
    $scope.LastNameSearch = "";
    $scope.EmptyPerson = { Id: "0", FirstName: "", LastName: "", Age: "" };
    $scope.ClearSelectedPerson = function () {
        $scope.SelectedPerson = angular.copy($scope.EmptyPerson);
    }
    $scope.ClearSelectedPerson();
    $scope.Edit = function (person) {
        $scope.SetErrorMessage("");
        $scope.SelectedPerson = angular.copy(person);
        $scope.personform.$setPristine();
        $scope.EditTitle = "Edit " + person.FirstName + " " + person.LastName;
        $scope.ShowEditForm = !$scope.ShowEditForm;
    }
    $scope.New = function (person) {
        $scope.SetErrorMessage("");
        $scope.ClearSelectedPerson();
        $scope.personform.$setPristine();
        $scope.EditTitle = "Add new person";
        $scope.ShowEditForm = !$scope.ShowEditForm;
    }
    $scope.Save = function () {
        $scope.SetErrorMessage("");
        var Method = "POST";
        var URL = '/api/People/'
        if ($scope.SelectedPerson.Id != 0) {
            Method = "PUT"
            URL = '/api/People/' + $scope.SelectedPerson.Id;
        }
         $http({
             method: Method,
             url: URL,
             data: $.param({
                 Id: $scope.SelectedPerson.Id,
                 FirstName: $scope.SelectedPerson.FirstName,
                 LastName: $scope.SelectedPerson.LastName,
                 Age: $scope.SelectedPerson.Age
            }),
            headers : {'Content-Type': 'application/x-www-form-urlencoded'} 
        })
          .success(function(data) {
              $scope.GetPeople()
              $scope.ShowEditForm = !$scope.ShowEditForm;
          }).error(function (data, status, header, config) {
              $scope.SetErrorMessage(data.Message);
          });
    }
    $scope.DeleteName = "";
    $scope.DeleteId = "";
    $scope.ConfirmDelete = function(person){
        $scope.DeleteName = person.FirstName + " " + person.LastName;
        $scope.DeleteId = person.Id;
        $('#DeleteModal').modal('show');
    }
    $scope.Delete = function (Id) {
       
        $scope.SetErrorMessage("");
        $('#DeleteModal' + Id + '').on('hidden.bs.modal', function () {
            alert("")
        })
        $http({
            method: 'DELETE',
            url: '/api/People/' + Id,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        })
         .success(function (data) {
             $scope.GetPeople()
         }).error(function (data, status, header, config) {
             $scope.SetErrorMessage(data.Message);
         });
    }
    $scope.Cancel = function (person) {
        $scope.SetErrorMessage("");
        $scope.ShowEditForm = !$scope.ShowEditForm;
    }
    $scope.GetPeople = function () {
        $scope.SetErrorMessage("");
        $http.get("/api/People/").then(function (response) {
            if (response.data.length == 0) {
                $scope.Peoplefound = false;
            } else {
                $scope.Peoplefound = true;
            }
            $scope.people = response.data;
        });
    }
    $scope.FirstNameSearch = "";
    $scope.GetPeopleByFirstName = function () {
        $scope.SetErrorMessage("");
        $http({
            method: 'GET',
            url: '/api/People/',
            params: { FirstName: $scope.FirstNameSearch }
        }).then(function successCallback(response) {
            if (response.data.length == 0) {
                $scope.Peoplefound = false;
            } else {
                $scope.Peoplefound = true;
            }
            $scope.people = response.data;
        }, function errorCallback(response) {
            $scope.SetErrorMessage(response.statusText);
        });
    } 
    $scope.LastNameSearch = "";
    $scope.GetPeopleByLastName = function () {
        $scope.SetErrorMessage("");
        $http({
            method: 'GET',
            url: '/api/People/',
            params: { LastName: $scope.LastNameSearch }
        }).then(function successCallback(response) {
            if (response.data.length == 0) {
                $scope.Peoplefound = false;
            } else {
                $scope.Peoplefound = true;
            }
            $scope.people = response.data;
        }, function errorCallback(response) {
            $scope.SetErrorMessage(response.statusText);
        });
    }
    $scope.GetPeople();

});

